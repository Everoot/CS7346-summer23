This folder would be used to store at text files the results returned by
\mod_vpl\tokenizer\tokenizer::get_all_tokens for all Behat test files.
Notice that output would be located at your Moodle instead of this repository.