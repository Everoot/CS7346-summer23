This folder would be used to store at text files the results returned by
vpl_tokenizer.class parse method for all Behat test files. Notice that
output would be located at your Moodle instead of this repository.
